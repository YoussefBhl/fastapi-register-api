STATUS = {"verified": "verified", "pending": "pending"}
CODE_MIN = 1000 
CODE_MAX = 9999
CODE_EXPIRE_IN = 60
